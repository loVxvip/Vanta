package ru.vanta.visuals

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var preview: CrosshairView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(12, 12, 18)
        window.navigationBarColor = android.graphics.Color.rgb(12, 12, 18)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(android.graphics.Color.rgb(12, 12, 18))
        }
        val title = TextView(this).apply {
            text = "VANTA VISUALS"
            textSize = 25f
            setTextColor(0xFFB79CFF.toInt())
        }
        page.addView(title)
        val subtitle = TextView(this).apply {
            text = "Настройка визуального прицела"
            textSize = 15f
            setTextColor(0xFFE4E0EF.toInt())
            setPadding(0, dp(6), 0, dp(16))
        }
        page.addView(subtitle)

        preview = CrosshairView(this)
        page.addView(preview, LinearLayout.LayoutParams(-1, dp(180)))

        fun label(s: String) = TextView(this).apply {
            text = s
            textSize = 14f
            setTextColor(0xFFE4E0EF.toInt())
            setPadding(0, dp(12), 0, dp(4))
        }
        page.addView(label("Размер прицела"))
        val size = SeekBar(this).apply {
            max = 80
            progress = 28
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    preview.arm = 8 + value
                    preview.invalidate()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        page.addView(size)

        page.addView(label("Толщина линий"))
        val thickness = SeekBar(this).apply {
            max = 12
            progress = 3
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    preview.stroke = 1f + value
                    preview.invalidate()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        page.addView(thickness)

        page.addView(label("Цвет прицела"))
        val colors = listOf("Фиолетовый", "Зелёный", "Красный", "Белый")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, colors)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                preview.color = when (position) {
                    1 -> 0xFF55FF99.toInt()
                    2 -> 0xFFFF5555.toInt()
                    3 -> 0xFFFFFFFF.toInt()
                    else -> 0xFFB79CFF.toInt()
                }
                preview.invalidate()
            }
        }
        page.addView(spinner)

        val note = TextView(this).apply {
            text = "Это отдельное приложение для предварительного просмотра прицела. Оно не внедряется в Standoff 2 и не меняет игровые файлы."
            textSize = 12f
            setTextColor(0xFFAAA5B5.toInt())
            setPadding(0, dp(18), 0, 0)
        }
        page.addView(note)
        setContentView(ScrollView(this).apply { addView(page) })
    }
}

class CrosshairView(context: android.content.Context) : View(context) {
    var arm = 36
    var stroke = 4f
    var color = 0xFFB79CFF.toInt()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(0xFF191722.toInt())
        paint.color = color
        paint.strokeWidth = stroke
        val cx = width / 2f
        val cy = height / 2f
        val gap = 8f
        canvas.drawLine(cx - arm, cy, cx - gap, cy, paint)
        canvas.drawLine(cx + gap, cy, cx + arm, cy, paint)
        canvas.drawLine(cx, cy - arm, cx, cy - gap, paint)
        canvas.drawLine(cx, cy + gap, cx, cy + arm, paint)
    }
}
